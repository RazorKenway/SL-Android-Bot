let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `

*YouTube:*
SL android 🇱🇰 

*සිංහලෙන් පයිතන් ඉගෙනගමු*

මෙතෙක් පලවූ සියලු වීඩියෝ මෙම post එක පහල දාලා තියෙනවා මුල ඉදලාම බලලා ඉගෙනගන්න. 

Chanel එක subscribe කරලා සහයෝගය ලබාදෙන්න,අනිත් අයටත් බලන්න share කරන්න.

Episode 01 - python හැඳින්වීම
   https://youtu.be/xwxauFsCYmk

Episode 02 - විචල්‍යන් (variables )
   https://youtu.be/0OpPQ51v0hs

Episode 03 - විචල්‍ය නාමකරණය
   https://youtu.be/5ESY5G6-NAU

Episode 04 - විචල්‍ය පැවරුම් 
   https://youtu.be/AZqpxVAjfvU

Episode 05 - print function 
   https://youtu.be/k18CYJPWm3E

Episode 06 - python Data types
   https://youtu.be/9AjunP0EYy0

Episode 07 -input function in python 
   https://youtu.be/0xrIK1kbfok

Episode 08 - Python Comments
   https://youtu.be/hh2eiYwON4o

Episode 09 -len Function in Python 
   https://youtu.be/vSkwUTjh97Y

Episode 10- sep & end in python 
   https://youtu.be/VUfBgzGYNkw

Episode 11 -index operator in python 
   https://youtu.be/7UyVUimLR04

Episode 12 -Slicing operator in python 
   https://youtu.be/a4Ss_7HJpyU

Episode 13-Get Data Type & Data Type conversion 
   https://youtu.be/DSSiR1m3fBQ

Episode 14-Get Data Type & Data Type conversion 

Episode 15-Ip Address Checker For Python | පයිතන් වලින් Ip Address Checker එකක් හදමු |Sinhala python|SL Android
    https://youtu.be/x40nWOEuhxk

If Function in python | Sinhala python Tutorials Episode 16 | SL Android
    https://youtu.be/H6mXg5QePoY

If else Statement in Python | Sinhala Python Tutorials Episode 17 | SL Android
    https://youtu.be/kcce7nLc7qk

If elif elif Else Statement In Python | Python Sinhala Tutorials Episode 18 | SL Android
    https://youtu.be/r2QwVA0kwDU

For Loop In Python programming | Python Sinhala Tutorials Episode 19 |SL Android
    https://youtu.be/uxXLey22WsY

For Loop With else , break ,continue ,pass | Python Sinhala Tutorials Episode 20 | SL Android
    https://youtu.be/TUe5dMCD4-s

While Loop In Python programming | Python Sinhala Tutorials Episode 21 | SL Android
    https://youtu.be/zEvcj6pmCL8

`.trim(), m)
}
handler.command = /^(python|Python)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler


