let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
Tutorial SL Android Whatsapp Bot
Credit: Razor Kenway 

_You can see the tutorial at_

*Our Youtube:*
*SL Android*  🇱🇰 

Subscribe Now :https://www.youtube.com/c/SLAndroid


`.trim(), m)
}
handler.command = /^(tutorial)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

