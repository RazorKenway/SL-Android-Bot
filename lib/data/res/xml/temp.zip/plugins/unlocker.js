let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `

*YouTube:*
SL android 🇱🇰 

                 💢  *UNLOCKER* 💢
      💢 *This Tool By Razor Kenway* 💢

❤️unlock All sks ,tmt, tut files

*හොදට මතක තියා ගන්න අපි unlock කරන්න යන sks හරි මොකක් හරි එක Unlocker කියන Folder එක ඇතුලේ එහෙමත් නැත්තම් Tool එකේ Folder එක ඇතුලේ තියෙන්න ඕන* 

වීඩීයෝ 2ක් තියෙනවා 2ම බලලා ඉන්න නැත්තම් තේරෙන්නෙ නෑ

💢 Vedio 1 -https://youtu.be/XVRuDqu_d3w

💢 Vedio 2 -https://t.me/c/1374078574/70


*Termux installation* 👇👇


pkg update && pkg upgrade

pkg install git

git clone https://github.com/RazorKenway/Unlocker.git

*දැන් අර sks file එක Tool එකේ Folder එකට දා ගන්නගන්න*

cd Unlocker 

python requirements.py

python3 decrypt.py (File name)

|

*Welcome To SL Android Youtube Channel*
                                💢 Disclaimer 💢
SL ANDROID Channel Doesn't Promote & Encourage Any illegal Activities, SL ANDROID YouTube Channel All Contents Only Provided by Education &Purpose Only. Thanks for watching.

*Follow Us On Facebook Page* https://www.facebook.com/SLAndroidD/

*Join Facebook Group* https://www.facebook.com/groups/277920623081269/

*Follow Us On Instagram* https://www.instagram.com/sl_android_official/

*Subscribe My youtube Channel* https://www.youtube.com/c/SLAndroid

*Thak you very mutch*

© *Razor Kenway*




`.trim(), m)
}
handler.command = /^(Unlocker | unlocker)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

