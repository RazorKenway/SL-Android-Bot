let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `

*YouTube:*
SL android 🇱🇰 

💢*Termux සිංහලෙන් ඉගෙනගමු.*

           *Termux Full course (Sinhala)*

   *Android phone ලේසියෙන් hack කරමු*
   *Wifi Hack කරමු
   *Facebook Hack කරමු
   *ඕනම phone එකක pin lock / pattern
     lock උස්සමු
   *සහ තවත් දේවල්







`.trim(), m)
}
handler.command = /^(termux|Termux)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

