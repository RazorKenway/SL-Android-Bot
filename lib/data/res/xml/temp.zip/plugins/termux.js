let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `

*YouTube:*
SL android 🇱🇰 

💢*Termux සිංහලෙන් ඉගෙනගමු.*

           *Termux Full course (Sinhala)*

   *Android phone ලේසියෙන් hack කරමු*
   *Wifi Hack කරමු
   *Facebook Hack කරමු
   *ඕනම phone එකක pin lock / pattern
     lock උස්සමු
   *සහ තවත් දේවල්

💢*දනට කරපු ඔක්කොම වීඩියෝ  ටික*

Termux Introduction(හැදින්වීම) | Termux Sinhala Tutorials | Episode 01 |SL Android
     https://youtu.be/MoFUaGHBNMs

Termux Basic Commands(මූලික විධාන)| Termux Sinhala Tutorials | Episode 02 |SL Android
     https://youtu.be/6P76zSVTm9Y

Termux Packages(පැකේජ) | Termux Sinhala Tutorials | Episode 03 |SL Android
     https://youtu.be/Ci-sVwOOy6M

Programming language On Termux | Termux Sinhala Tutorials | Episode 04 |SL Android
    https://youtu.be/M9cAGBgEm4A

Termux Tools(ටූල්ස් හදුනාගැනීම)| Termux Sinhala Tutorials | Episode 05 |SL Android
    https://youtu.be/FxBwMC0Y2Uk

Termux Tools Part 2 Vulnerable Scanning| Termux Sinhala Tutorials Episode 06 | SL Android |SL Coders
    https://youtu.be/pL1-HwMz2tM

Termux Android Usage Commands | Termux Sinhala Tutorials Episode 07 | SL Android | SL Coders
    https://youtu.be/xc_001aET1U

How to Get Termux Themes & Font Styles | Termux Sinhala Tutorials Episode 08 | SL Android
    https://youtu.be/J1n4RyahwEI

How to remove Termux Tools / Derectory | Termux Sinhala Tutorials Episode 09 | SL Android
    https://youtu.be/q3yFRKHFtZE

How to Set Termux Banner(බැනර් එකක්)| Termux සිංහල  Tutorials Episode 11 | SL Android
    https://youtu.be/lPawbriU5XE

How To Backup Installed Termux Tools | Termux සිංහල  Tutorials Episode 12 | SL Android
    https://youtu.be/0LjVNpC2UWQ

How to install Metasploit Framework On Termux | Termux සිංහල  Tutorials Episode 14 | SL Android
    https://youtu.be/7HXxocx5RtQ

How to set EvilEye-Banner on termux | Termux Sinhala Tutorials Episode 17 | SL android 
    https://youtu.be/AlHIMXjpU30

EvilEye-Banner Update Version | Termux Sinhala Tutorials Episode 18 | SL android 
    https://youtu.be/zV5fQK3dg9g

How to Send SMS For Your Friends | Termux Sinhala Tutorials Episode 23 | SL Android
    https://youtu.be/Gw6eU_fwwbw

How To Create Own Termux Script Sinhala  Episode 23 part 01 | SL Android
    https://youtu.be/rmM4IyiQATw

How To Create Own Termux Script Sinhala  Episode 23 part 02 | SL Android
    https://youtu.be/urTdzck-nck

How To Create Own Termux Script Sinhala  Episode 23 part 03 | SL Android
    https://youtu.be/rSn7nMTZjJU

How To Create Own Termux Script Sinhala  Episode 23 part 04 | SL Android
    https://youtu.be/fuKtlOiXvA8

How To Create Own Termux Script Sinhala  Episode 23 part 05 | SL Android
    https://youtu.be/kSZkRU4R-VQ

How To Create A Useless Termux Programme | Termux Sinhala Tutorial Episode 29 | SL Android
    https://youtu.be/DyFmpiJO3l4

How To Lock Termux User Interface | Termux Lock Tool |Termux Sinhala Tutorial Episode 30| SL Android
    https://youtu.be/QVHQqBnXY-Q

`.trim(), m)
}
handler.command = /^(termux|Termux)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

