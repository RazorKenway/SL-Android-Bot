let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
                      🇸​​​​​🇱​​​​​ 🇦​​​​​🇳​​​​​🇩​​​​​🇷​​​​​🇴​​​​​🇮​​​​​🇩​​​​​     🇱🇰 

╠══〘 SL Android Official 〙BOT  ═
║
╠➥ YouTube: https://www.youtube.com/c/SLAndroid
╠➥ Facebook Group : https://www.facebook.com/groups/277920623081269/?ref=share
╠➥ Razor Kenway ( SL Android )
║
╠══〘 SL Android Official Bot═
║
╠➥   MAKE GROUP ADMIN 
╠➥   TURN ON YOUR DATA
╠➥   CONTACT : Razor Kenway (Owner)
║
║>Request >>>>> Razor Kenway
║
╠══〘 SL Android Official  〙BOT  ═
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
